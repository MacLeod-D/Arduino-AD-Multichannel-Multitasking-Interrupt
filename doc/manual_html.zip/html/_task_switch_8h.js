var _task_switch_8h =
[
    [ "popall", "_task_switch_8h.html#a75736d8377302454457d0b6287b8e8b5", null ],
    [ "pushall", "_task_switch_8h.html#a3ab2d8db832098ad27b998928f6152c6", null ],
    [ "StartMultiTasking", "_task_switch_8h.html#a28d6350ba2c6f99d81fbe99760109e9c", null ],
    [ "freeRam", "_task_switch_8h.html#aac7b29dc45caaaca67299571f6a2dcc0", null ],
    [ "Idle", "_task_switch_8h.html#a2242f9428023ff0aacadb5fa210a6686", null ],
    [ "resume_task", "_task_switch_8h.html#a61240a6fa8fbf5b98b0d2e93e8e10839", null ],
    [ "stop_task", "_task_switch_8h.html#a821c2f4021b7f0e06bb827b25b18eb9a", null ],
    [ "stopMe", "_task_switch_8h.html#a9887033f4678ad6ba112b565ebebd632", null ],
    [ "TaskInit", "_task_switch_8h.html#a827fd8dd8b4182d2693a93c5bd712f14", null ],
    [ "TaskSwitch", "_task_switch_8h.html#ab193ea1d36a77882a2aa938f7bba3947", null ],
    [ "Yield", "_task_switch_8h.html#a2a66f7ffc1635ebc3aa118d246de679f", null ]
];