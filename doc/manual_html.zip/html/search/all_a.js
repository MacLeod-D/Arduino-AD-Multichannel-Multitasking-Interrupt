var searchData=
[
  ['task_5f1ms',['Task_1ms',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#ae5a3bda07ecd4886cab7801b291442c1',1,'Task_1ms():&#160;ADC_Interrupt_Nano.ino'],['../Task_1ms.html',1,'(Global Namespace)']]],
  ['task_5floop',['Task_Loop',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#ac29b50b8927f487a4a2b556502187d8a',1,'Task_Loop():&#160;ADC_Interrupt_Nano.ino'],['../Task_Loop.html',1,'(Global Namespace)']]],
  ['timing_2ejpg',['Timing.jpg',['../d0/d77/_timing_8jpg.html',1,'']]]
];
