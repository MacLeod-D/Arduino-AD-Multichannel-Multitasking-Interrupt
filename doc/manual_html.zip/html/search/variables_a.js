var searchData=
[
  ['serhead',['SerHead',['../_my_serial_8h.html#ac2f79a65ac9d058695f09e5d372904a6',1,'MySerial.h']]],
  ['sertail',['SerTail',['../_my_serial_8h.html#ab3b3ad48bc7e70ba20b7efc2aa28cbcc',1,'MySerial.h']]],
  ['sp_5fsave',['sp_save',['../structtask.html#a0c19ae47b96c819447ed90112c792a23',1,'task']]],
  ['stacklen',['stackLen',['../structtask.html#af07aa691ab40afb8543956e52813ae93',1,'task']]],
  ['stacklow',['StackLow',['../_coop_o_s___stack___m_t___nano_8ino.html#abb40b5e25f8b09c2d5faa915bf7553a2',1,'CoopOS_Stack_MT_Nano.ino']]],
  ['state',['state',['../structtask.html#a38f098f1aca88a9cc3982ccc109bcadc',1,'task']]],
  ['state2',['state2',['../structtask.html#a9615bc2dcadf48dd466abf3f80740366',1,'task']]],
  ['state2txt',['State2Txt',['../_coop_o_s___stack___m_t___nano_8ino.html#ad149620b5e12343772a3631f2e128441',1,'CoopOS_Stack_MT_Nano.ino']]]
];
