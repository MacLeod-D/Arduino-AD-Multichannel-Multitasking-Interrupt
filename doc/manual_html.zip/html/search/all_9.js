var searchData=
[
  ['setup',['setup',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'ADC_Interrupt_Nano.ino']]],
  ['strpt',['strpt',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#a3e60dce8f766eb146109aa07c87a9fae',1,'ADC_Interrupt_Nano.ino']]]
];
