var searchData=
[
  ['read',['read',['../classmy_serial.html#a95c09f04c36c584a4fa488fe88984daa',1,'mySerial']]],
  ['resume_5ftask',['resume_task',['../_task_switch_8h.html#a61240a6fa8fbf5b98b0d2e93e8e10839',1,'TaskSwitch.h']]]
];
