var searchData=
[
  ['ser_5fbuf_5fmax',['SER_BUF_MAX',['../_my_serial_8h.html#a9734d6bc7e5e118c96ecf2f7b4f65040',1,'MySerial.h']]],
  ['startmultitasking',['StartMultiTasking',['../_task_switch_8h.html#a28d6350ba2c6f99d81fbe99760109e9c',1,'TaskSwitch.h']]]
];
