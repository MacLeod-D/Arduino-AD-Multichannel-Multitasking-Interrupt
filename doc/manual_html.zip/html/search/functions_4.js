var searchData=
[
  ['task_5f1ms',['Task_1ms',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#ae5a3bda07ecd4886cab7801b291442c1',1,'ADC_Interrupt_Nano.ino']]],
  ['task_5floop',['Task_Loop',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#ac29b50b8927f487a4a2b556502187d8a',1,'ADC_Interrupt_Nano.ino']]]
];
