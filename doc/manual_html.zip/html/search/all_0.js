var searchData=
[
  ['ad_2dinterrupts',['AD-Interrupts',['../AD-Interrupts.html',1,'']]],
  ['adc_5finterrupt_5fnano_2eino',['ADC_Interrupt_Nano.ino',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html',1,'']]],
  ['alpha',['Alpha',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#adac1aa2956b7d24e6b63da5719bf8865',1,'ADC_Interrupt_Nano.ino']]],
  ['analogval',['analogVal',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#a07a89985ae8c351b822b5d95df7fabf6',1,'ADC_Interrupt_Nano.ino']]],
  ['av',['av',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#a52a4f5adcc1a24024682007199df8964',1,'ADC_Interrupt_Nano.ino']]]
];
