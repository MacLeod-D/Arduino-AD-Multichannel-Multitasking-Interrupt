var searchData=
[
  ['max_5ftasks',['MAX_TASKS',['../_coop_o_s___stack___m_t___nano_8ino.html#aac747bed84189f8cfa509b94d488e622',1,'CoopOS_Stack_MT_Nano.ino']]],
  ['max_5ftotal_5fstack_5flen',['MAX_TOTAL_STACK_LEN',['../_coop_o_s___stack___m_t___nano_8ino.html#a9388aab52157aa06c5988a0efc2e8711',1,'CoopOS_Stack_MT_Nano.ino']]]
];
