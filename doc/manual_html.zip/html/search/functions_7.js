var searchData=
[
  ['taskinit',['TaskInit',['../_task_switch_8h.html#a827fd8dd8b4182d2693a93c5bd712f14',1,'TaskSwitch.h']]],
  ['taskswitch',['TaskSwitch',['../_task_switch_8h.html#ab193ea1d36a77882a2aa938f7bba3947',1,'TaskSwitch.h']]],
  ['toser',['toSer',['../classmy_serial.html#afc96dc0fa2c40f1fe193c6244633d3f8',1,'mySerial']]]
];
