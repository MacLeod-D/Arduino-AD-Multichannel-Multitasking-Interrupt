var searchData=
[
  ['lasttasktime',['lastTaskTime',['../d9/d0b/_a_d_c___interrupt___nano_8ino.html#a3420d0791ade66803d8d5a88b9863ba6',1,'ADC_Interrupt_Nano.ino']]]
];
