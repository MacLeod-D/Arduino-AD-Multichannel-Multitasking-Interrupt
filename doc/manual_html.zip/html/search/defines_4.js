var searchData=
[
  ['popall',['popall',['../_task_switch_8h.html#a75736d8377302454457d0b6287b8e8b5',1,'TaskSwitch.h']]],
  ['pushall',['pushall',['../_task_switch_8h.html#a3ab2d8db832098ad27b998928f6152c6',1,'TaskSwitch.h']]]
];
