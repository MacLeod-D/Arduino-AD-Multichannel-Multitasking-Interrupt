var searchData=
[
  ['setserial',['setSerial',['../classmy_serial.html#abb648a8f8cfac003b6cebc0f0b116408',1,'mySerial']]],
  ['stop_5ftask',['stop_task',['../_task_switch_8h.html#a821c2f4021b7f0e06bb827b25b18eb9a',1,'TaskSwitch.h']]],
  ['stopme',['stopMe',['../_task_switch_8h.html#a9887033f4678ad6ba112b565ebebd632',1,'TaskSwitch.h']]]
];
