var NAVTREE =
[
  [ "ADC_Interrupt_Nano", "index.html", [
    [ "Overview", "index.html", null ],
    [ "AD-Interrupts", "AD-Interrupts.html", null ],
    [ "Loop", "Loop.html", null ],
    [ "Task_Loop", "Task_Loop.html", null ],
    [ "Task_1ms", "Task_1ms.html", null ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"AD-Interrupts.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';