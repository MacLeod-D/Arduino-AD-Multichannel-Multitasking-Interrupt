var _a_d_c___interrupt___nano_8ino =
[
    [ "CHNUM", "_a_d_c___interrupt___nano_8ino.html#a33416115a597e9305f34924b2a384cb5", null ],
    [ "IRQ_SAMPLES", "_a_d_c___interrupt___nano_8ino.html#a665287843e54185a17330af919e822dd", null ],
    [ "ftoa", "_a_d_c___interrupt___nano_8ino.html#ac76c1ac758595f0ecaa7898d17694d04", null ],
    [ "ISR", "_a_d_c___interrupt___nano_8ino.html#a05c2e5b588ced1cd7312f5b0edc5b295", null ],
    [ "loop", "_a_d_c___interrupt___nano_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_a_d_c___interrupt___nano_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "Task_1ms", "_a_d_c___interrupt___nano_8ino.html#ae5a3bda07ecd4886cab7801b291442c1", null ],
    [ "Task_Loop", "_a_d_c___interrupt___nano_8ino.html#ac29b50b8927f487a4a2b556502187d8a", null ],
    [ "Alpha", "_a_d_c___interrupt___nano_8ino.html#adac1aa2956b7d24e6b63da5719bf8865", null ],
    [ "analogVal", "_a_d_c___interrupt___nano_8ino.html#a07a89985ae8c351b822b5d95df7fabf6", null ],
    [ "av", "_a_d_c___interrupt___nano_8ino.html#a52a4f5adcc1a24024682007199df8964", null ],
    [ "Busy", "_a_d_c___interrupt___nano_8ino.html#abfd7bb487ac6cf2d745d287ece245d8f", null ],
    [ "Channel", "_a_d_c___interrupt___nano_8ino.html#a05a615640be75e78d7fd2074ddf9a336", null ],
    [ "IrqReadyFlag", "_a_d_c___interrupt___nano_8ino.html#ae3633d2ce7905e0984282f8d12fcbeb8", null ],
    [ "lastTaskTime", "_a_d_c___interrupt___nano_8ino.html#a3420d0791ade66803d8d5a88b9863ba6", null ],
    [ "oldVal", "_a_d_c___interrupt___nano_8ino.html#a7239f5f97fbea77b3fbde70d1737eed1", null ],
    [ "out", "_a_d_c___interrupt___nano_8ino.html#a78ea880de30af517dbb7abdc9f8a419c", null ],
    [ "pt", "_a_d_c___interrupt___nano_8ino.html#a6c968ee6eb10c4ba386621ba90472862", null ],
    [ "strpt", "_a_d_c___interrupt___nano_8ino.html#a3e60dce8f766eb146109aa07c87a9fae", null ],
    [ "val", "_a_d_c___interrupt___nano_8ino.html#a26f18cc5d2179adc30fc1a7544962178", null ]
];