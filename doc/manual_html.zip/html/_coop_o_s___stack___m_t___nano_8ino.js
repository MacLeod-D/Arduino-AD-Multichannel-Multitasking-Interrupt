var _coop_o_s___stack___m_t___nano_8ino =
[
    [ "avv", "_coop_o_s___stack___m_t___nano_8ino.html#a8613bb39418452b23239218ddab4ff34", null ],
    [ "ADCSRA", "_coop_o_s___stack___m_t___nano_8ino.html#ad953a689205988a14b93829c946a999b", null ],
    [ "av", "_coop_o_s___stack___m_t___nano_8ino.html#ad2a0f184241fb088782778efb6ad093f", null ],
    [ "Busy", "_coop_o_s___stack___m_t___nano_8ino.html#aef4755ef61c93d98637d8efce19a31aa", null ],
    [ "oldVal", "_coop_o_s___stack___m_t___nano_8ino.html#ad7e663d4235a8ed575c58e12119d7dce", null ],
    [ "possible", "_coop_o_s___stack___m_t___nano_8ino.html#afcda53af05c3c05f9f19c2d28641c127", null ]
];